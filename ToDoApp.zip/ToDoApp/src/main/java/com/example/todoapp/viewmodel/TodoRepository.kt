package com.example.todoapp.viewmodel

import com.example.todoapp.data.TodoDao
import com.example.todoapp.data.TodoEntity

class TodoRepository(private val dao: TodoDao) {
    suspend fun getTodos() = dao.getAll()
    suspend fun insert(todo: TodoEntity) = dao.insert(todo)
    suspend fun update(todo: TodoEntity) = dao.update(todo)
    suspend fun delete(todo: TodoEntity) = dao.delete(todo)
}
