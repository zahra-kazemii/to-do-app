package com.example.todoapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.room.Room
import com.example.todoapp.data.TodoDatabase
import com.example.todoapp.viewmodel.TodoRepository
import com.example.todoapp.ui.theme.MainScreen
import com.example.todoapp.ui.theme.TodoappTheme
import com.example.todoapp.viewmodel.TodoViewModel
import com.example.todoapp.viewmodel.TodoViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val db = Room.databaseBuilder(applicationContext, TodoDatabase::class.java, "todo_db").build()
        val repository = TodoRepository(db.todoDao())
        val viewModel = TodoViewModelFactory(repository).create(TodoViewModel::class.java)

        setContent {
            TodoappTheme {
                MainScreen(activity = this, viewModel = viewModel)
            }
        }

    }
}
