package com.example.todoapp.data

import androidx.room.*

@Dao
interface TodoDao {
    @Query("SELECT * FROM todos ORDER BY isDone ASC, date ASC, time ASC")
    suspend fun getAll(): List<TodoEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(todo: TodoEntity)

    @Update
    suspend fun update(todo: TodoEntity)

    @Delete
    suspend fun delete(todo: TodoEntity)
}
