package com.example.todoapp.ui.theme

import androidx.activity.ComponentActivity
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.todoapp.data.TodoEntity
import com.example.todoapp.viewmodel.TodoViewModel
import com.example.todoapp.ui.theme.components.TodoInputDialog
import com.example.todoapp.ui.theme.components.TodoItemCard
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

enum class FilterMode { All, Done, NotDone }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(activity: ComponentActivity, viewModel: TodoViewModel) {
    var showInputDialog by remember { mutableStateOf(false) }
    var editingTodo by remember { mutableStateOf<TodoEntity?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var isSearchMode by remember { mutableStateOf(false) }
    var filterMode by remember { mutableStateOf(FilterMode.All) }

    val todos by viewModel.todos.collectAsState()

    val filteredAndSortedTodos by remember(todos, searchQuery, filterMode) {
        derivedStateOf {
            var filtered = if (searchQuery.isBlank()) todos else todos.filter {
                it.title.contains(searchQuery,
                    ignoreCase = true)
            }
            filtered = when (filterMode) {
                FilterMode.Done -> filtered.filter { it.isDone }
                FilterMode.NotDone -> filtered.filter { !it.isDone }
                FilterMode.All -> filtered
            }
            filtered.sortedWith(
                compareBy<TodoEntity> { it.isDone }
                    .thenBy { todo ->
                        try {
                            val formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm")
                            LocalDateTime.parse("${todo.date} ${todo.time}", formatter)
                        } catch (e: Exception) {
                            LocalDateTime.MAX
                        }
                    }
            )
        }
    }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(230.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0xFF008173),
                                    Color(0xFF00A193)
                                )
                            )
                        )
                        .padding(horizontal = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "منو",
                        color = Color.White,
                        fontSize = 24.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }

                Spacer(Modifier.height(16.dp))

                NavigationDrawerItem(
                    label = { Text("صفحه اصلی") },
                    icon = {
                        Icon(Icons.Default.Home,
                        contentDescription = "صفحه اصلی")
                           },
                    selected = filterMode == FilterMode.All,
                    onClick = {
                        scope.launch { drawerState.close() }
                        filterMode = FilterMode.All
                    }
                )
                NavigationDrawerItem(
                    label = { Text("کارهای انجام شده") },
                    icon = {
                        Icon(Icons.Default.CheckBox,
                        contentDescription = "کارهای انجام شده")
                           },
                    selected = filterMode == FilterMode.Done,
                    onClick = {
                        scope.launch { drawerState.close() }
                        filterMode = FilterMode.Done
                    }
                )

                NavigationDrawerItem(
                    label = { Text("کارهای انجام نشده") },
                    icon = {
                        Icon(Icons.Default.CheckBoxOutlineBlank,
                            contentDescription = "کارهای انجام نشده")
                           },
                    selected = filterMode == FilterMode.NotDone,
                    onClick = {
                        scope.launch { drawerState.close() }
                        filterMode = FilterMode.NotDone
                    }
                )

                Spacer(Modifier.weight(1f))

                NavigationDrawerItem(
                    label = { Text("خروج") },
                    icon = {
                        Icon(Icons.Default.ExitToApp,
                            contentDescription = "خروج")
                           },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        activity.finishAffinity()
                    }
                )
            }
        }
    ) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    AnimatedContent(targetState = isSearchMode, label = "") { state ->
                        if (state) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                placeholder = {
                                    Text(
                                        text = "جست و جو در کارها",
                                        modifier = Modifier.fillMaxWidth(),
                                        textAlign = TextAlign.Right,
                                        maxLines = 1
                                    )
                                },
                                leadingIcon = {
                                    Icon(Icons.Default.Search,
                                        contentDescription = null,
                                        tint = Color.Gray)
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(55.dp),
                                shape = RoundedCornerShape(50),
                                singleLine = true,
                                textStyle = LocalTextStyle.current.copy(
                                    fontSize = 14.sp,
                                    textAlign = TextAlign.Right
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color.Transparent,
                                    unfocusedBorderColor = Color.Transparent,
                                    focusedContainerColor = Color.White,
                                    unfocusedContainerColor = Color.White
                                )
                            )
                        } else {
                            if (filterMode == FilterMode.All) {
                                val currentDate = LocalDate.now()
                                val formatter = DateTimeFormatter.ofPattern("EEEE, MMMM d")
                                val formattedDate = currentDate.format(formatter)
                                Text(
                                    text = formattedDate,
                                    modifier = Modifier.fillMaxWidth(),
                                    textAlign = TextAlign.Center,
                                    fontSize = 18.sp
                                )
                            } else {
                                val title = when (filterMode) {
                                    FilterMode.Done -> "کارهای انجام شده"
                                    FilterMode.NotDone -> "کارهای انجام نشده"
                                    else -> ""
                                }
                                Text(
                                    text = title,
                                    modifier = Modifier.fillMaxWidth(),
                                    textAlign = TextAlign.Center,
                                    fontSize = 18.sp
                                )
                            }
                        }
                    }
                },
                navigationIcon = {
                    if (!isSearchMode) {
                        IconButton(onClick = {
                            scope.launch { drawerState.open() }
                        }) {
                            Icon(
                                imageVector = Icons.Filled.Menu,
                                contentDescription = "Menu"
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = {
                        isSearchMode = !isSearchMode
                        if (!isSearchMode) {
                            searchQuery = ""
                        }
                    }) {
                        Icon(
                            imageVector = if (isSearchMode) Icons.Default.Close else Icons.Default.Search,
                            contentDescription = if (isSearchMode) "لغو جستجو" else "جستجو",
                            tint = Color.White
                        )
                    }
                },
                modifier = Modifier.background(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF008173),
                            Color(0xFF00A193)
                        )
                    )
                ),
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent,
                    titleContentColor = Color.White,
                    actionIconContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingTodo = null
                    showInputDialog = true
                },
                containerColor = Color(0xFF008173),
                contentColor = Color.White
            ) { Icon(imageVector = Icons.Filled.Add, contentDescription = "Add") }
        },
        content = { innerPadding ->
            Column(
                modifier = Modifier.padding(innerPadding).padding(top = 24.dp).fillMaxSize(),
                verticalArrangement = Arrangement.Top,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (todos.isEmpty() && searchQuery.isBlank()) {
                    Box(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 32.dp, vertical = 300.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            ".هنوز کاری اضافه نشده است",
                            color = Color.Gray, fontSize = 20.sp,
                            modifier = Modifier.fillMaxSize(),
                            textAlign = TextAlign.Center)
                    }
                } else if (filteredAndSortedTodos.isEmpty() && searchQuery.isNotBlank()) {
                    Box(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 32.dp, vertical = 300.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(".نتیجه‌ای یافت نشد",
                            color = Color.Gray,
                            fontSize = 16.sp,
                            modifier = Modifier.fillMaxSize(),
                            textAlign = TextAlign.Center)
                    }
                } else {
                    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 16.dp)) {
                        items(filteredAndSortedTodos.size) { index ->
                            val todo = filteredAndSortedTodos[index]
                            TodoItemCard(
                                todo = todo,
                                onToggleDone = { toggledTodo ->
                                    viewModel.updateTodo(toggledTodo.copy(isDone = !toggledTodo.isDone))
                                },
                                onDelete = { viewModel.deleteTodo(todo) },
                                onEdit = {
                                    editingTodo = it
                                    showInputDialog = true
                                }
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                    }
                }
            }
        }
    )
}


    if (showInputDialog) {
        TodoInputDialog(
            onDismiss = { showInputDialog = false },
            onSave = { savedTodo ->
                if (editingTodo != null) {
                    viewModel.updateTodo(savedTodo.copy(id = editingTodo!!.id, isDone = editingTodo!!.isDone))
                } else {
                    viewModel.addTodo(savedTodo)
                }
            },
            initialTodo = editingTodo
        )
    }
}
