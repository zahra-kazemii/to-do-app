package com.example.todoapp.ui.theme.components

import android.app.DatePickerDialog as AndroidDatePickerDialog
import android.app.TimePickerDialog as AndroidTimePickerDialog
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.todoapp.data.TodoEntity
import java.util.Calendar
import android.widget.DatePicker as AndroidDatePicker


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TodoInputDialog(
    onDismiss: () -> Unit,
    onSave: (TodoEntity) -> Unit,
    initialTodo: TodoEntity? = null
) {
    var title by remember { mutableStateOf(initialTodo?.title ?: "") }
    var date by remember { mutableStateOf(initialTodo?.date ?: "") }
    var time by remember { mutableStateOf(initialTodo?.time ?: "") }
    var showError by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val isEdit = initialTodo != null
    var showEmptyFieldError by remember { mutableStateOf(false) }
    val isEditMode = initialTodo != null

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            dismissOnBackPress = true,
            dismissOnClickOutside = false
        )
    ) {
        Surface(
            modifier = Modifier
                .wrapContentSize()
                .padding(16.dp),
            shape = MaterialTheme.shapes.medium,
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
            ) {
                Text(
                    text = if (isEditMode) "ویرایش کار" else "افزودن کار",
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    textAlign = TextAlign.Center
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = {
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = Alignment.CenterEnd
                        ) {
                            Text("عنوان", color = Color.Gray)
                        }
                    },
                    placeholder = {
                        Text("عنوان را وارد کنید", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Right, color = Color.Gray)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.Gray.copy(alpha = 0.2f),
                        unfocusedBorderColor = Color.Gray.copy(alpha = 0.2f),
                        disabledBorderColor = Color.Gray.copy(alpha = 0.2f)
                    ),
                    textStyle = LocalTextStyle.current.copy(textAlign = TextAlign.Right, color = Color.Gray),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = date,
                    onValueChange = {},
                    enabled = false,
                    label = {
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = Alignment.CenterEnd
                        ) {
                            Text("تاریخ")
                        }
                    },
                    placeholder = {
                        Text("تاریخ را انتخاب کنید", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Right)
                    },
                    trailingIcon = {
                        Icon(imageVector = Icons.Filled.CalendarToday, contentDescription = "انتخاب تاریخ")
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            val calendar = Calendar.getInstance()
                            AndroidDatePickerDialog(
                                context,
                                { _: AndroidDatePicker, year: Int, month: Int, dayOfMonth: Int ->
                                    date = String.format("%04d/%02d/%02d", year, month + 1, dayOfMonth)
                                },
                                calendar.get(Calendar.YEAR),
                                calendar.get(Calendar.MONTH),
                                calendar.get(Calendar.DAY_OF_MONTH)
                            ).show()
                        },
                    colors = OutlinedTextFieldDefaults.colors(Color.LightGray),
                    textStyle = LocalTextStyle.current.copy(textAlign = TextAlign.Right),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = time,
                    onValueChange = {},
                    enabled = false,
                    label = {
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = Alignment.CenterEnd
                        ) {
                            Text("ساعت")
                        }
                    },
                    placeholder = {
                        Text("ساعت را انتخاب کنید", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Right)
                    },
                    trailingIcon = {
                        Icon(imageVector = Icons.Filled.Alarm, contentDescription = "انتخاب ساعت")
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            val calendar = Calendar.getInstance()
                            AndroidTimePickerDialog(
                                context,
                                { _, hourOfDay, minute ->
                                    time = String.format("%02d:%02d", hourOfDay, minute)
                                },
                                calendar.get(Calendar.HOUR_OF_DAY),
                                calendar.get(Calendar.MINUTE),
                                true
                            ).show()
                        },
                    colors = OutlinedTextFieldDefaults.colors(Color.LightGray),
                    textStyle = LocalTextStyle.current.copy(textAlign = TextAlign.Right),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                if (showEmptyFieldError) {
                    Text(
                        text = ".لطفا اطلاعات را تکمیل کنید",
                        color = Color.Red,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Right
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Start
                ) {
                    Button(
                        onClick = {
                            if (title.isEmpty() || date.isEmpty() || time.isEmpty()) {
                                showEmptyFieldError = true
                            } else {
                                showEmptyFieldError = false
                                val updatedOrNewTodo = if (isEditMode) {
                                    initialTodo!!.copy(title = title, date = date, time = time)
                                } else {
                                    TodoEntity(title = title, date = date, time = time)
                                }
                                onSave(updatedOrNewTodo)
                                onDismiss()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF008173))
                    ) {
                        Text(if (isEditMode) "ویرایش" else "ذخیره")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    TextButton(onClick = onDismiss) {
                        Text("لغو", color = Color.Black)
                    }
                }
            }
        }
    }
}